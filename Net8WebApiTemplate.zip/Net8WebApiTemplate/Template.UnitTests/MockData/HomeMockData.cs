﻿using Template.Models;

namespace Template.UnitTests.MockData
{
    public class HomeMockData
    {
        public static ExampleModel GetFromRedisValue() 
        {
            return new ExampleModel();
        }

        public static ExampleModel GetFromRedisValueEmpty()
        {
            return null;
        }
    }
}
