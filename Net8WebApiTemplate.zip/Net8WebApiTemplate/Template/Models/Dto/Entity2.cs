﻿namespace Template.Models.Dto
{
    public class Entity2
    {

        public string Id { get; set; }
        public string key { get; set; }
        public string value { get; set; }

    }
}
