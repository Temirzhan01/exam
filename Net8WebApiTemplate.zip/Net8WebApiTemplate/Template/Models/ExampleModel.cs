﻿namespace Template.Models
{
    public class ExampleModel
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
