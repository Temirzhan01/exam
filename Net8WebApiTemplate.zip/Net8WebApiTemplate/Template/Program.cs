using Serilog.Formatting.Elasticsearch;
using Serilog;
using Template.Extensions.Configuration;
using Template.Extensions.MiddleWares;
using Template.Extensions;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Newtonsoft.Json;

var builder = WebApplication.CreateBuilder(args);

builder.AddConsulConfiguration(); // Получаем конфигурации проекта из консула, при первичном запуске проекта

builder.AddServices(); // Внедряем все зависимости проекта

Serilog.Debugging.SelfLog.Enable(Console.Error);

Log.Logger = new LoggerConfiguration() // Настраиваем глобальный логгер проекта Serilog, с выводом в консоль логов, читаем для Еластика формате
    .Enrich.FromLogContext()
    .WriteTo.Console(new ElasticsearchJsonFormatter())
    .CreateLogger();

builder.Host.UseSerilog();

var app = builder.Build();

app.MapHealthChecks("/healthz", new HealthCheckOptions // Добавляем entrypoint для получения хелзчека работы приложения, и настраиваем для вывода в едином формате 
{
    ResponseWriter = async (context, report) => {
        context.Response.ContentType = "application/json";
        var result = new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(x => new { name = x.Key, response = x.Value.Status.ToString(), description = x.Value.Description })
        };
        await context.Response.WriteAsync(JsonConvert.SerializeObject(result));
    }
});

if (builder.Configuration["SwaggerEnvironment"] == "Development")
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ApiKeyMiddleware>(); // Используем кастомный компонент middleware для аутентификации на основе апи ключа

app.UseHttpsRedirection();

app.UseStaticFiles();

app.MapControllers();

app.Run();
