﻿using Microsoft.EntityFrameworkCore;
using Template.Models.Dto;

namespace Template.Data
{
    public class PostgreDbContext : DbContext
    {
        public PostgreDbContext (DbContextOptions options) : base(options) { }
        public virtual DbSet<Entity2> Entities2 { get; set; } = null!;
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }
    }
}
