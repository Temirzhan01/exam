﻿using Microsoft.EntityFrameworkCore;
using Template.Data;
using Template.Models.Dto;
using Template.Repositories.Abstract;

namespace Template.Repositories
{
    public class PostgreEntity2Repository : IRepository<Entity2>
    { 
        private readonly PostgreDbContext _context;
        public PostgreEntity2Repository(PostgreDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Entity2>> GetAllAsync() 
        {
            return await _context.Entities2.ToListAsync();
        }
        public async Task<Entity2> GetByIdAsync(int id) 
        {
            return await _context.Entities2.FindAsync(id);
        }
        public async Task AddAsync(Entity2 entity) 
        {
            await _context.Entities2.AddAsync(entity);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(Entity2 entity) 
        {
            _context.Entities2.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id) 
        {
            var entity = await _context.Entities2.FindAsync(id);
            if (entity != null)
            {
                _context.Entities2.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
