﻿using Microsoft.AspNetCore.Mvc;
using Template.Models;
using Template.Services.Abstract;

namespace Template.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IService _service;

        public HomeController(ILogger<HomeController> logger, IService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        [Route("GetAllFromDBOracle")]
        public async Task<ActionResult> GetAllFromDBOracle() 
        {
            return Ok(await _service.GetAllFromDBOracle());
        }

        [HttpGet]
        [Route("GetAllFromDBPostgre")]
        public async Task<ActionResult> GetAllFromDBPostgre()
        {
            return Ok(await _service.GetAllFromDBPostgre());
        }

        [HttpGet]
        [Route("GetFromRedis/{key}")]
        public async Task<ActionResult> GetFromRedis(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return BadRequest();
            }
            var result = await _service.GetFromRedis(key);
            if (result == null) 
            {
                return NoContent();
            }
            return Ok(result);
        }

        [HttpPost]
        [Route("SetInRedis/{key}/{value}")]
        public async Task<ActionResult> SetInRedis(string key, string value)
        {
            if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
            {
                return BadRequest();
            }
            await _service.SetInRedis(key, value);
            return Ok();
        }

        [HttpPost]
        [Route("ProduceToKafka")]
        public async Task<ActionResult> ProduceToKafka([FromBody] ExampleModel body)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                await _service.Produce(body.key, body);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("ProduceToKafka" + ex.InnerException.Message);
                return StatusCode(500, new { message = ex.InnerException.Message });
            }
        }

        [HttpPost]
        [Route("RestExternalServiceCall")]
        public async Task<IActionResult> RestExternalServiceCall()
        {
            return Ok(await _service.RestServiceCall());
        }

        [HttpPost]
        [Route("SoapExternalServiceCall")]
        public async Task<IActionResult> SoapExternalServiceCall()
        {
            await _service.SoapServiceCall();
            return Ok();
        }
    }
}
