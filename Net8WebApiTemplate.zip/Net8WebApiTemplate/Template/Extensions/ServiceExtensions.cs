﻿using Microsoft.EntityFrameworkCore;
using Template.Data;
using Template.Models.Dto;
using Template.Extensions.HealthChecks;
using Polly;
using Template.Services.Abstract;
using Template.Services;
using Template.Repositories.Abstract;
using StackExchange.Redis;
using Template.Repositories;
using ServiceReference;
using System.ServiceModel;

namespace Template.Extensions
{
    public static class ServiceExtensions
    {
        public static WebApplicationBuilder AddServices(this WebApplicationBuilder builder)
        {
            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", builder => builder.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(_ => true));
            });
            builder.Services.AddHealthChecks(builder.Configuration); // добавляем кастомные хелзчеки

            builder.Services.AddDbContext<OracleDbContext>(options =>
            {
                options.UseOracle(builder.Configuration.GetConnectionString("OracleConnectionString"));
            });
            builder.Services.AddDbContext<PostgreDbContext>(options =>
            {
                options.UseNpgsql(builder.Configuration.GetConnectionString("NpgsqlConnectionString"));
            });
            builder.Services.AddScoped<IRepository<Entity>, OracleEntityRepository>();
            builder.Services.AddScoped<IRepository<Entity2>, PostgreEntity2Repository>();

            builder.Services.AddScoped<IService, Service>();
            builder.Services.AddHttpClient("ExampleREST", (serviceProvider, client) => // внедряем именнового клиента, с дефолтным url и настройками политик обработок запросов
            {
                client.BaseAddress = new Uri(builder.Configuration["ExternalServices:REST:ExampleRESTURL"]);
            })
            .AddTransientHttpErrorPolicy(p => p.CircuitBreakerAsync(5, TimeSpan.FromSeconds(30))); // добавляем политику, вкл паттерна CircuitBreaker который посел 5 неудачных попыток, будет автоматом выдавать Exception, и попытается достуаться еще раз после 30 сек
            
            builder.Services.AddSingleton<IKafkaProducer<string, string>, KafkaProducer<string, string>>(); // внедряем продюсера кафки

            builder.Services.AddSingleton<IConnectionMultiplexer>(sp =>  // внедряем настройки подключения к редису
            {
                return ConnectionMultiplexer.Connect(ConfigurationOptions.Parse(builder.Configuration["Redis:ConnectionString"]));
            });
            builder.Services.AddTransient<IRedisService, RedisService>();

            builder.Services.AddTransient<PublisherSoapClient>(provider => // внедряем клиента soap сервиса, с явным указанием url
            {
                var serviceURL = new Uri(builder.Configuration["ExternalServices:SOAP:ExampleSOAPURL"]);
                return new PublisherSoapClient(new BasicHttpBinding(), new EndpointAddress(serviceURL));
            });

            return builder;
        }
    }
}
