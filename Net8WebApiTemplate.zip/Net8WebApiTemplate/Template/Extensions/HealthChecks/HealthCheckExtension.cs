﻿using Confluent.Kafka;

namespace Template.Extensions.HealthChecks
{
    public static class HealthCheckExtension
    {
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration) 
        {
            services.AddHealthChecks()
                .AddOracle(configuration.GetConnectionString("OracleConnectionString") ?? "", name: "Cardcolv"); // Добавляем хелзчек для бд оракл

            services.AddHealthChecks()
                .AddNpgSql(configuration.GetConnectionString("NpgsqlConnectionString") ?? "", name: "Somenpgsqldb"); // Добавляем хелзчек для бд Пострге
            
            services.AddHealthChecks() // Добавляем для топика Кафки
                .AddKafka(options =>
                {
                    options.BootstrapServers = configuration["KafkaSettings:BootstrapServers"];
                    options.MessageTimeoutMs = 1000;
                    options.SecurityProtocol = SecurityProtocol.SaslSsl;
                    options.SaslMechanism = SaslMechanism.ScramSha256;
                    options.SaslUsername = configuration["KafkaSettings:SaslUsername"];
                    options.SaslPassword = configuration["KafkaSettings:SaslPassword"];
                }, name: "Kafka", topic: configuration["KafkaSettings:Topic"]);

            services.AddHealthChecks() // Добавляем для редиса
                .AddRedis(configuration["Redis:ConnectionString"], name: "redis");

            // Получаем секцию с внешними сервисами как словарь
            var restExternalServices = configuration.GetSection("ExternalServices").GetSection("REST").Get<Dictionary<string, string>>(); // Добавляем хелзчеки для всех рестовых сервисов на сетевой доступ
            foreach (var service in restExternalServices)
            {
                string name = service.Key; // Название сервиса, например "HHDService"
                string url = service.Value; // URL сервиса

                if (!string.IsNullOrWhiteSpace(url))
                {
                    // Добавляем health check для каждого URL
                    services.AddHealthChecks().AddUrlGroup(new Uri(url), name: name);
                }
            }

            return services;
        }
    }
}
