﻿namespace Template.Extensions.MiddleWares
{
    public class ApiKeyMiddleware
    {
        private const string ApiKeyHeaderName = "X-APi-Key";
        private readonly RequestDelegate _next;
        private readonly IConfiguration _configuration;

        public ApiKeyMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _configuration = configuration;
        }

        public async Task InvokeAsync(HttpContext context)         
        {
            if (context.Request.Path.HasValue && !context.Request.Path.Value.Contains("/healthz") && context.Request.Headers.Referer.Contains("swagger"))  // проверки пути текущего запроса
            {
                if (!context.Request.Headers.TryGetValue(ApiKeyHeaderName, out var receivedKey))  // проверка на наличие заголовка в запросе
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("Api Key is missing");
                    return;
                }
                string validKey = _configuration["ApiKey"];
                if (receivedKey != validKey) 
                {
                    context.Response.StatusCode = 403;
                    await context.Response.WriteAsync("Invalid Api Key");
                    return;
                }
            }
            await _next(context);
        }
    }
}
