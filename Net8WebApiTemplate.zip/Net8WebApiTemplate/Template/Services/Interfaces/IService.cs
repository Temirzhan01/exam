﻿using Template.Models;
using Template.Models.Dto;

namespace Template.Services.Abstract
{
    public interface IService
    {
        Task<IEnumerable<Entity>> GetAllFromDBOracle();
        Task<IEnumerable<Entity2>> GetAllFromDBPostgre();
        Task<ExampleModel> RestServiceCall();
        Task SoapServiceCall();
        Task<ExampleModel> GetFromRedis(string key);
        Task SetInRedis(string key, string value);
        Task Produce(string key, ExampleModel model);
    }
}
