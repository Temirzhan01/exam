﻿namespace Template.Services.Abstract
{
    public interface IKafkaProducer<Tkey, TValue>
    {
        Task ProduceAsync(Tkey key, TValue value);
    }
}
