﻿using Confluent.Kafka;
using Template.Services.Abstract;

namespace Template.Services
{
    public class KafkaProducer<TKey, TValue> : IKafkaProducer <TKey, TValue>, IDisposable
    {
        private readonly ILogger<KafkaProducer<TKey, TValue>> _logger;
        private readonly IProducer<TKey, TValue> _producer;
        private readonly string _topic;

        public KafkaProducer(IConfiguration configuration, ILogger<KafkaProducer<TKey, TValue>> logger)
        {
            _topic = configuration["KafkaSettings:Topic"];
            var config = new ProducerConfig()
            {
                BootstrapServers = configuration["KafkaSettings:BootstrapServers"],
                Acks = Acks.Leader,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.ScramSha256,
                EnableSslCertificateVerification = false,
                SaslUsername = configuration["KafkaSettings:SaslUsername"],
                SaslPassword = configuration["KafkaSettings:SaslPassword"]
            };

            _producer = new ProducerBuilder<TKey, TValue>(config)
                .SetErrorHandler((_, e) => Console.WriteLine($"Error: {e.Reason}"))
                .SetLogHandler((_, logMessage) => Console.WriteLine($"Log: {logMessage.Message}"))
                .Build();
            _logger = logger;
        }

        public static async Task ProduceAsync(ProducerConfig config, string topic, string key, string message)
        {
            using (var producer = new ProducerBuilder<string, string>(config).Build())
            {
                var result = await producer.ProduceAsync(topic, new Message<string, string> { Key = key, Value = message });
            }
        }

        public async Task ProduceAsync(TKey key, TValue value)
        {
            try
            {
                var result = await _producer.ProduceAsync(_topic, new Message<TKey, TValue> { Key = key, Value = value });
            }
            catch (ProduceException<TKey, TValue> e)
            {
                _logger.LogError($"Failed to deliver message: {e.Error.Reason}");
            }
        }
        public void Dispose()
        {
            _producer?.Dispose();
        }

    }
}
