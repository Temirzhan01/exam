﻿using Newtonsoft.Json;
using Template.Models.Dto;
using Template.Repositories.Abstract;
using Template.Services.Abstract;
using System.Text;
using Template.Models;
using ServiceReference;
using Template.Extensions;

namespace Template.Services
{
    public class Service : IService
    {
        private readonly ILogger<Service> _logger;
        private readonly IRepository<Entity> _oracleEntityRepo;
        private readonly IRepository<Entity2> _postgreEntityRepo;
        private readonly HttpClient _httpClient;
        private readonly IRedisService _redisService;
        private readonly IKafkaProducer<string, string> _producer;
        private readonly PublisherSoapClient _publisher;

        public Service(IConfiguration configuration, ILogger<Service> logger, IHttpClientFactory factory, IRedisService redisService, IKafkaProducer<string, string> producer, IRepository<Entity> oracleRepo, IRepository<Entity2> postgreRepo, PublisherSoapClient publisher)
        {
            _logger = logger;
            _httpClient = factory.CreateClient("RESTClient");
            _redisService = redisService;
            _producer = producer;
            _postgreEntityRepo = postgreRepo;
            _oracleEntityRepo = oracleRepo;
            _publisher = publisher;

        }
        public async Task<IEnumerable<Entity>> GetAllFromDBOracle()
        {
            try
            {
                return await _oracleEntityRepo.GetAllAsync();
            }
            catch (Exception ex)
            {
                string Action = "GetAllFromDBOracle";
                _logger.LogErrorCustom(Action, ex.Message, JsonConvert.SerializeObject(ex.InnerException.Message));
                throw ex;
            }
        }

        public async Task<IEnumerable<Entity2>> GetAllFromDBPostgre()
        {
            return await _postgreEntityRepo.GetAllAsync();
        }

        public async Task<ExampleModel> RestServiceCall()
        {
            var content = new StringContent(JsonConvert.SerializeObject(new { Example = "Example" }), Encoding.UTF8, "application/json");
            var message = new HttpRequestMessage(HttpMethod.Post, $"/somepathtoendpoint") { Content = content };
            using (HttpResponseMessage response = await _httpClient.SendAsync(message))
            {
                response.EnsureSuccessStatusCode();
                return JsonConvert.DeserializeObject<ExampleModel>(await response.Content.ReadAsStringAsync());
            }
        }
        public async Task SoapServiceCall()
        {
            await _publisher.GetModelAsync();
        }

        public async Task<ExampleModel> GetFromRedis(string key)
        {
            return JsonConvert.DeserializeObject<ExampleModel>(await _redisService.GetValueAsync(key));
        }

        public async Task SetInRedis(ExampleModel model)
        {
            await _redisService.SetValueAsync(model);
        }

        public async Task Produce(string key, ExampleModel model)
        {
            await _producer.ProduceAsync(key, JsonConvert.SerializeObject(model));
        }
    }
}
