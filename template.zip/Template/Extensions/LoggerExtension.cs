﻿namespace Template.Extensions
{
    public static class LoggerExtension
    {
        public static void LogErrorCustom(this ILogger logger, string action, string message, string additionalData) 
        {
            logger.LogError($"Action: {action}, Error message: {message}, Additional data: {additionalData}");
        }

        public static void LogInfoCustom(this ILogger logger, string action, string message, string additionalData)
        {
            logger.LogInformation($"Action: {action}, Info message: {message}, Additional data: {additionalData}");
        }
    }
}
