﻿namespace Template.Extensions.Configuration
{
    public static class ConsulConfigurationExtensions
    {
        public static WebApplicationBuilder AddConsulConfiguration(this WebApplicationBuilder builder)
        {
            var configBuilder = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();

            var builtConfig = configBuilder.Build();
            configBuilder.Add(new ConsulConfigurationSource(builtConfig["Host"], builtConfig["Environment"]));

            var config = configBuilder.Build();
            builder.Configuration.AddConfiguration(config);

            return builder;
        }
    }

    public class ConsulConfigurationSource : IConfigurationSource
    {
        private readonly string _consulAddress;
        private readonly string _key;

        public ConsulConfigurationSource(string consulAddress, string key)
        {
            _consulAddress = consulAddress;
            _key = key;
        }

        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new ConsulConfigurationProvider(_consulAddress, _key);
        }
    }
}
