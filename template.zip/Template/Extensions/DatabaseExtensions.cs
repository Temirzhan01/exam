﻿using Microsoft.EntityFrameworkCore;
using Template.Data;

namespace Template.Extensions
{
    public static class DatabaseExtensions
    {
        public static WebApplicationBuilder AddDbContexts(this WebApplicationBuilder builder)
        {
            builder.Services.AddDbContext<OracleDbContext>(options =>
            {
                options.UseOracle(builder.Configuration.GetConnectionString("OracleConnectionString"));
            });
            builder.Services.AddDbContext<PostgreDbContext>(options =>
            {
                options.UseNpgsql(builder.Configuration.GetConnectionString("NpgsqlConnectionString"));
            });

            return builder;
        }
    }
}
