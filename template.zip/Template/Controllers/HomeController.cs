﻿using Microsoft.AspNetCore.Mvc;
using Template.Extensions;
using Template.Models;
using Template.Services.Abstract;

namespace Template.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IService _service;

        public HomeController(ILogger<HomeController> logger, IService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        [Route("GetAllFromDBOracle")]
        public async Task<ActionResult> GetAllFromDBOracle()
        {
            return Ok(await _service.GetAllFromDBOracle());
        }

        [HttpGet]
        [Route("GetAllFromDBPostgre")]
        public async Task<ActionResult> GetAllFromDBPostgre()
        {
            return Ok(await _service.GetAllFromDBPostgre());
        }

        [HttpGet]
        [Route("GetFromRedis/{key}")]
        public async Task<ActionResult> GetFromRedis(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return BadRequest();
            }
            var result = await _service.GetFromRedis(key);
            if (result == null)
            {
                return NoContent();
            }
            return Ok(result);
        }

        [HttpPost]
        [Route("SetInRedis/{key}/{value}")]
        public async Task<ActionResult> SetInRedis([FromBody] ExampleModel model) // Тут завернуто в try catch так как это пост метод, который не возвращает ответа
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _service.SetInRedis(model);
            return Ok();

        }

        [HttpPost]
        [Route("ProduceToKafka")]
        public async Task<ActionResult> ProduceToKafka([FromBody] ExampleModel body)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _service.Produce(body.key, body);
            return Ok();
        }

        [HttpPost]
        [Route("RestExternalServiceCall")]
        public async Task<IActionResult> RestExternalServiceCall()
        {
            return Ok(await _service.RestServiceCall());
        }

        [HttpPost]
        [Route("SoapExternalServiceCall")]
        public async Task<IActionResult> SoapExternalServiceCall()
        {
            await _service.SoapServiceCall();
            return Ok();
        }
    }
}
