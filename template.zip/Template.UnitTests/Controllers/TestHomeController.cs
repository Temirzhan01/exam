﻿using Moq;
using FluentAssertions;
using Template.Services.Abstract;
using Template.Controllers;
using Microsoft.AspNetCore.Mvc;
using Template.UnitTests.MockData;

namespace Template.UnitTests.Controllers
{
    public class TestHomeController
    {
        private Mock<IService> _serviceMock = new Mock<IService>();

        public TestHomeController(Mock<IService> mock)
        {
            _serviceMock = new Mock<IService>();
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn200Status()
        {
            /// Arrange
            string key = "Key";
            _serviceMock.Setup(service => service.GetFromRedis(key)).ReturnsAsync(HomeMockData.GetFromRedisValue());
            var _controller = new HomeController(null, _serviceMock.Object);

            /// Act
            var result = (OkObjectResult)await _controller.GetFromRedis(key);

            /// Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn204NoContentStatus()
        {
            /// Arrange
            string key = "Key";
            _serviceMock.Setup(service => service.GetFromRedis(key)).ReturnsAsync(HomeMockData.GetFromRedisValueEmpty());
            var _controller = new HomeController(null, _serviceMock.Object);

            /// Act
            var result = (NoContentResult)await _controller.GetFromRedis(key);

            /// Assert
            result.StatusCode.Should().Be(204);
            _serviceMock.Verify(service => service.GetFromRedis(key), Times.Exactly(1));
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn400BadRequestStatus()
        {
            /// Arrange
            _serviceMock.Setup(service => service.GetFromRedis(""));
            var _controller = new HomeController(null, _serviceMock.Object);

            /// Act
            var result = (BadRequestResult)await _controller.GetFromRedis("");

            /// Assert
            result.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn500OnException()
        {
            // Arrange
            string key = "Key";
            _serviceMock.Setup(service => service.GetFromRedis(key))
                        .ThrowsAsync(new Exception("Database error"));
            var controller = new HomeController(null, _serviceMock.Object);

            // Act
            var result = (ObjectResult)await controller.GetFromRedis(key);

            // Assert
            result.StatusCode.Should().Be(500);
            result.Value.Should().Be("An error occurred while processing your request.");
        }
    }
}
