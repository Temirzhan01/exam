﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using TcrServiceMonitoring.Models;
using TcrServiceMonitoring.Services;

namespace TcrServiceMonitoring.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class TcrController : ControllerBase
    {
        private readonly ITcrService _service;
        private readonly ILogger<TcrController> _logger;
        public TcrController(ITcrService service, ILogger<TcrController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetAllErrorRequests/{fromDate}/{toDate}")]
        public async Task<ActionResult<IEnumerable<ErrorRequest>>> GetAllErrorRequests(string fromDate, string toDate)
        {
            _logger.LogInformation($"FromDate: {fromDate} || Todate: {toDate}");
            if (string.IsNullOrEmpty(fromDate) && string.IsNullOrEmpty(toDate))
            {
                return BadRequest("Null parametr(s)");
            }
            return Ok(await _service.GetAllErrorRequests(fromDate, toDate));
        }

        [HttpGet]
        [Route("GetAllSuccesRequests/{fromDate}/{toDate}")]
        public async Task<ActionResult<IEnumerable<SuccessRequest>>> GetAllSuccesRequests(string fromDate, string toDate)
        {
            _logger.LogInformation($"FromDate: {fromDate} || Todate: {toDate}");
            if (string.IsNullOrEmpty(fromDate) && string.IsNullOrEmpty(toDate))
            {
                return BadRequest("Null parametr(s)");
            }
            return Ok(await _service.GetAllSuccesRequests(fromDate, toDate));
        }

    }
}
