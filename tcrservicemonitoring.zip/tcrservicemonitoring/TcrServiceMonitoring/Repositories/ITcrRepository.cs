﻿using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using System.Threading.Tasks;
using TcrServiceMonitoring.Models;

namespace TcrServiceMonitoring.Repositories
{
    public interface ITcrRepository
    {
        public Task<List<ErrorRequest>> GetAllErrorRequests(string fromDate, string toDate);
        public Task<List<SuccessRequest>> GetAllSuccesRequests(string fromDate, string toDate);
    }
}
