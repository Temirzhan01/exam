﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using TcrServiceMonitoring.Models;
using Consul;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using SpmModels;
using SPMUtils;
using System.Net.Http;

namespace TcrServiceMonitoring.Repositories
{
    public class TcrRepository : ITcrRepository
    {
        private readonly IConsulClient _consulClient;
        private readonly IConfiguration _configuration;

        public TcrRepository(IConsulClient consulClient, IConfiguration configuration)
        {
            _configuration = configuration;
            _consulClient = consulClient;
        }

        public ConnectionStringToBase config
        {
            get
            {
                var configData = Task.Run(async () => await _consulClient.KV.Get(_configuration["Environment:ConsulKvName"]));
                return JsonConvert.DeserializeObject<ConnectionStringToBase>(configData.Result.Response.Value.toString());
            }
        }

        public async Task<List<ErrorRequest>> GetAllErrorRequests(string fromDate, string toDate)
        {
            var result = new List<ErrorRequest>();
            using (OracleConnection conn = new OracleConnection(config.CARDCOLV))
            {
                OracleCommand cmd = new OracleCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "cardcolv.PKG_TCR.GETALLERRORREQUESTS";
                cmd.Parameters.Add("FROMDATE", OracleDbType.NVarchar2, fromDate, ParameterDirection.Input);
                cmd.Parameters.Add("TODATE", OracleDbType.NVarchar2, toDate, ParameterDirection.Input);
                cmd.Parameters.Add("CUR_OUT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                await conn.OpenAsync();
                cmd.Connection = conn;
                OracleDataReader reader = (OracleDataReader)await cmd.ExecuteReaderAsync();
                while (reader.Read())
                {
                    result.Add(new ErrorRequest()
                    {
                        RequestNumber = reader["REQUEST_NUMBER"].ToString(),
                        UpdateDate = reader["UPDATE_DATE"].ToString(),
                        Operation = reader["OPERATION"].ToString(),
                        Currency = reader["CURRENCY"].ToString(),
                        Initiator = reader["INITIATOR"].ToString(),
                        Uname = reader["UNAME"].ToString(),
                        ErrorText = reader["ERROR_TEXT"].ToString(),
                        ErrorDescription = reader["ERROR_DESCRIPTION"].ToString(),
                        TcrModel = reader["TCRMODEL"].ToString()
                    });
                }
                reader.Dispose();
                conn.Close();
            }
            return result;
        }

        public async Task<List<SuccessRequest>> GetAllSuccesRequests(string fromDate, string toDate)
        {
            var result = new List<SuccessRequest>();
            using (OracleConnection conn = new OracleConnection(config.CARDCOLV))
            {
                await conn.OpenAsync();
                OracleCommand cmd = new OracleCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "cardcolv.PKG_TCR.GETALLSUCCESSREQUESTS";
                cmd.Parameters.Add("FROMDATE", OracleDbType.Varchar2, fromDate, ParameterDirection.Input);
                cmd.Parameters.Add("TODATE", OracleDbType.Varchar2, toDate, ParameterDirection.Input);
                cmd.Parameters.Add("CUR_OUT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Connection = conn;
                OracleDataReader reader = (OracleDataReader)await cmd.ExecuteReaderAsync();
                while (reader.Read())
                {
                    result.Add(new SuccessRequest()
                    {
                        RequestNumber = reader["REQUEST_NUMBER"].ToString(),
                        UpdateDate = reader["UPDATE_DATE"].ToString(),
                        ClientName = reader["CLIENTNAME"].ToString(),
                        Operation = reader["OPERATION"].ToString(),
                        Currency = reader["CURRENCY"].ToString(),
                        Initiator = reader["INITIATOR"].ToString(),
                        UserName = reader["USERNAME"].ToString(),
                        TcrModel = reader["TCRMODEL"].ToString()
                    });
                }
                reader.Dispose();
                conn.Close();
            }
            return result;
        }

    }
}
