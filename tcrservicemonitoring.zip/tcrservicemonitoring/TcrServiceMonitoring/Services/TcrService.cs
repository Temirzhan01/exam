﻿using System.Collections.Generic;
using TcrServiceMonitoring.Models;
using TcrServiceMonitoring.Repositories;
using System;
using System.Globalization;
using System.Net.Http;
using System.Threading.Tasks;

namespace TcrServiceMonitoring.Services
{
    public class TcrService : ITcrService
    {
        private readonly ITcrRepository _repository;
        public TcrService(ITcrRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<ErrorRequest>> GetAllErrorRequests(string fromDate, string toDate)
        {
            if (IsValid(fromDate, toDate))
            {
                List<ErrorRequest> errors = await _repository.GetAllErrorRequests(fromDate, toDate);
                if (errors.Count > 0)
                {
                    return errors;
                }
                else
                {
                    throw new HttpRequestException($"No data found at this period({fromDate} - {toDate})");
                }
            }
            else
            {
                throw new HttpRequestException("Parametrs not valid");
            }
        }

        public async Task<List<SuccessRequest>> GetAllSuccesRequests(string fromDate, string toDate)
        {
            if (IsValid(fromDate, toDate))
            {
                List<SuccessRequest> successes = await _repository.GetAllSuccesRequests(fromDate, toDate);
                if (successes.Count > 0)
                {
                    return successes;
                }
                else
                {
                    throw new HttpRequestException($"No data found at this period({fromDate} - {toDate})");
                }
            }
            else
            {
                throw new HttpRequestException("Parametrs not valid");
            }
        }
        public bool IsValid(string fromDate, string toDate)
        {
            return true;
            if (fromDate.Length == 19 || toDate.Length == 19 && fromDate != toDate)
            {
                CultureInfo culture = new CultureInfo("ru-RU");
                culture.Calendar.TwoDigitYearMax = 2099;
                var dateFormat = "dd.MM.yyyy HH:mm:ss";
                if ((DateTime.ParseExact(toDate, dateFormat, culture) - DateTime.ParseExact(fromDate, dateFormat, culture)).TotalHours <= 24)
                {
                    return true;
                }
            }
            return false;
        }

    }
}
