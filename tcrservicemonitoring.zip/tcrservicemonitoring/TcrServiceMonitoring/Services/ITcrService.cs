﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TcrServiceMonitoring.Models;

namespace TcrServiceMonitoring.Services
{
    public interface ITcrService
    {
        public Task<List<ErrorRequest>> GetAllErrorRequests(string fromDate, string toDate);
        public Task<List<SuccessRequest>> GetAllSuccesRequests(string fromDate, string toDate);
    }
}
