﻿namespace TcrServiceMonitoring.Models
{
    public class ErrorRequest
    {
        public string RequestNumber { get; set; }
        public string Operation { get; set; }
        public string Currency{ get; set; }
        public string UpdateDate { get; set; }
        public string Initiator { get; set; }
        public string Uname { get; set; }
        public string ErrorText { get; set; }
        public string ErrorDescription { get; set; }
        public string TcrModel { get; set; }
    }
}
