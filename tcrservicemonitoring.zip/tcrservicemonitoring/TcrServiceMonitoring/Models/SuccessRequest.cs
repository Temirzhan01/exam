﻿namespace TcrServiceMonitoring.Models
{
    public class SuccessRequest
    {
        public string RequestNumber { get; set; }
        public string UpdateDate { get; set; }
        public string ClientName { get; set; }
        public string Operation { get; set; }
        public string Currency{ get; set; }
        public string Initiator { get; set; }
        public string UserName { get; set; }
        public string TcrModel { get; set; }
    }
}
