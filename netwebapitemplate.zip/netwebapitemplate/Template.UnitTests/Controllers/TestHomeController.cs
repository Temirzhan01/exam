﻿using Moq;
using FluentAssertions;
using Template.Services.Abstract;
using Template.Controllers;
using Microsoft.AspNetCore.Mvc;
using Template.UnitTests.MockData;

namespace Template.UnitTests.Controllers
{
    public class TestHomeController
    {
        private Mock<IRedisService> _redisServiceMock = new Mock<IRedisService>();

        public TestHomeController()
        {
            _redisServiceMock = new Mock<IRedisService>();
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn200Status()
        {
            /// Arrange
            string key = "Key";
            _redisServiceMock.Setup(service => service.GetValueAsync(key)).ReturnsAsync(HomeMockData.GetFromRedisValue());
            var _controller = new HomeController(null, null, _redisServiceMock.Object);

            /// Act
            var result = (OkObjectResult)await _controller.GetFromRedis(key);

            /// Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn204NoContentStatus()
        {
            /// Arrange
            string key = "Key";
            _redisServiceMock.Setup(service => service.GetValueAsync(key)).ReturnsAsync(HomeMockData.GetFromRedisValueEmpty());
            var _controller = new HomeController(null, null, _redisServiceMock.Object);

            /// Act
            var result = (NoContentResult)await _controller.GetFromRedis(key);

            /// Assert
            result.StatusCode.Should().Be(204);
            _redisServiceMock.Verify(service => service.GetValueAsync(key), Times.Exactly(1));
        }

        [Fact]
        public async Task GetFromRedisAsync_ShouldReturn400BadRequestStatus()
        {
            /// Arrange
            _redisServiceMock.Setup(service => service.GetValueAsync(""));
            var _controller = new HomeController(null, null, _redisServiceMock.Object);

            /// Act
            var result = (BadRequestResult)await _controller.GetFromRedis("");

            /// Assert
            result.StatusCode.Should().Be(400);
        }
    }
}
