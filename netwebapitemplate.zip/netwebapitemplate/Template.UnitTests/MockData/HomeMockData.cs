﻿namespace Template.UnitTests.MockData
{
    public class HomeMockData
    {
        public static string GetFromRedisValue() 
        {
            return "";
        }

        public static string GetFromRedisValueEmpty()
        {
            return null;
        }
    }
}
