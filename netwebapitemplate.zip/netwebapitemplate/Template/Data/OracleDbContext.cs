﻿using Microsoft.EntityFrameworkCore;
using Template.Models;

namespace Template.Data
{
    public class OracleDbContext : DbContext
    {
        public OracleDbContext(DbContextOptions<OracleDbContext> options) : base(options) { }
        public virtual DbSet<Entity> Entities { get; set; } = null!;
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Entity>(entity =>
            {
                entity.ToTable("Entities");

                entity.Property(e => e.Id)
                    .HasColumnType("NUMBER")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("ID");

                entity.Property(e => e.key)
                    .HasMaxLength(50)
                    .HasColumnName("KEY");

                entity.Property(e => e.value)
                    .HasMaxLength(50)
                    .HasColumnName("VALUE");
            });

            modelBuilder.HasSequence("Entities_SEQ");
        }
    }
}
