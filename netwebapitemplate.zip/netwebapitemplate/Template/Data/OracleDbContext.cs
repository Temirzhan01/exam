﻿using Microsoft.EntityFrameworkCore;
using Template.Models;

namespace Template.Data
{
    public class OracleDbContext : DbContext
    {
        public OracleDbContext(DbContextOptions<OracleDbContext> options) : base(options) { }
        public virtual DbSet<User> Users { get; set; } = null!;
    }
}
