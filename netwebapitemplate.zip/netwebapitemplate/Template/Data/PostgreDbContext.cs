﻿using Microsoft.EntityFrameworkCore;
using Template.Models;

namespace Template.Data
{
    public class PostgreDbContext : DbContext
    {
        public PostgreDbContext (DbContextOptions options) : base(options) { }
        public virtual DbSet<User> Users { get; set; } = null!;
    }
}
