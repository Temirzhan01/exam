﻿using System.ComponentModel.DataAnnotations;

namespace Template.Models
{
    public class ExampleModel
    {
        [Required]
        public string key { get; set; }
        [Required]
        public string value { get; set; }
    }
}
