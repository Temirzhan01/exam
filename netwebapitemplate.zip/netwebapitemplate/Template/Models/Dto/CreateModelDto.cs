﻿namespace Template.Models.Dto
{
    public class CreateModelDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}
