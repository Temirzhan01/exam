﻿namespace Template.Models.Dto
{
    public class ModelDto
    {
        public string FIO { get; set; }
        public string Email { get; set; }
    }
}
