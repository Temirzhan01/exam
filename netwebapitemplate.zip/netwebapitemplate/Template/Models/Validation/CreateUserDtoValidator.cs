﻿using FluentValidation;
using Template.Models.Dto;

namespace Template.Models.Validation
{
    public class CreateUserDtoValidator : AbstractValidator<CreateUserDto>
    {
        public CreateUserDtoValidator()
        {
            RuleFor(x => x.Login)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");

            RuleFor(x => x.Password)
                .NotEmpty().WithMessage("Password is required")
                .MinimumLength(8).WithMessage("Password must be at least 8 characters long")
                .MaximumLength(100).WithMessage("Password must not exceed 100 characters")
                .Matches("[A-Z]").WithMessage("Password must contain at least one uppercase letter")
                .Matches("[a-z]").WithMessage("Password must contain at least one lowercase letter")
                .Matches("[0-9]").WithMessage("Password must contain at least one digit")
                .Matches("[^a-zA-Z0-9]").WithMessage("Password must contain at least one special character");

            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email is required")
                .EmailAddress().WithMessage("Invalid email address");

            RuleFor(x => x.Phone)
                .NotEmpty().WithMessage("Phone is required")
                .Length(11, 50).WithMessage("Phone must be between 11 and 50")
                .Matches(@"^\d{10}$").WithMessage("Phone number must be exactly 10 digits");

            RuleFor(x => x.Birthday)
                .NotEmpty().WithMessage("Birthday is required");

            RuleFor(x => x.RegDate)
                .NotEmpty().WithMessage("Birthday is required")
                .LessThanOrEqualTo(DateTime.UtcNow).WithMessage("Registration date must be in the past")
                .GreaterThan(x => x.Birthday).WithMessage("Registration date must be greater than birthday");

            RuleFor(x => x.Age)
                .GreaterThan(18).WithMessage("Quantity must be greater than zero");

            RuleFor(x => x.FirstName)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");

            RuleFor(x => x.LastName)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");

            RuleFor(x => x.MiddleName)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");
        }
    }
}
