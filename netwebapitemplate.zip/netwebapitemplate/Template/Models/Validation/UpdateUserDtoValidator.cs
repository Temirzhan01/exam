﻿using FluentValidation;
using Template.Models.Dto;

namespace Template.Models.Validation
{
    public class UpdateUserDtoValidator : AbstractValidator<UpdateUserDto>
    {
        public UpdateUserDtoValidator()
        {
            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email is required")
                .EmailAddress().WithMessage("Invalid email address");

            RuleFor(x => x.Phone)
                .NotEmpty().WithMessage("Phone is required")
                .Length(11, 50).WithMessage("Phone must be between 11 and 50")
                .Matches(@"^\d{10}$").WithMessage("Phone number must be exactly 10 digits");

            RuleFor(x => x.Birthday)
                .NotEmpty().WithMessage("Birthday is required");

            RuleFor(x => x.RegDate)
                .NotEmpty().WithMessage("Birthday is required")
                .LessThanOrEqualTo(DateTime.UtcNow).WithMessage("Registration date must be in the past")
                .GreaterThan(x => x.Birthday).WithMessage("Registration date must be greater than birthday");

            RuleFor(x => x.Age)
                .GreaterThan(18).WithMessage("Quantity must be greater than zero");

            RuleFor(x => x.FirstName)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");

            RuleFor(x => x.LastName)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");

            RuleFor(x => x.MiddleName)
                .NotEmpty().WithMessage("Login is required")
                .Length(8, 50).WithMessage("Login must be between 8 and 50");
        }
    }
}
