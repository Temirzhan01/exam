﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Template.Models;
using Template.Services.Interfaces;

namespace Template.Controllers
{
    public class AuthController : Controller
    {
        private readonly ILogger<AuthController> _logger;
        private readonly IUserService _userService;
        private readonly IAuthService _authService;
        public AuthController(ILogger<AuthController> logger, IUserService userService, IAuthService authService) 
        {
            _logger = logger;
            _userService = userService;
            _authService = authService;
        }

        [HttpPost]
        [Route("token")]
        public async Task<IActionResult> GetToken([FromBody] User user)
        {
            var authentificatedUser = await _userService.CheckCredentialsAndGetAsync(user);
            if (authentificatedUser == null) 
            {
                return Unauthorized("Invalid credentials");
            }

            var token = await _authService.GenerateJWT(authentificatedUser);
            var refreshToken = await _authService.GenerateRefreshTokenAsync(user.Id.ToString());

            return Ok(new 
            {
                Token = token,
                RefreshToken = refreshToken
            });
        }


        [HttpPost]
        [Route("refresh/{refreshToken}")]
        public async Task<IActionResult> RefreshToken(string refreshToken) 
        {
            var authentificatedUser = await _authService.GetUserByRefreshTokenAsync(refreshToken);
            if (authentificatedUser == null) 
            {
                return Unauthorized("Invalid refresh token");
            }

            var token = await _authService.GenerateJWT(authentificatedUser);
            var newRefreshToken = await _authService.GenerateRefreshTokenAsync(authentificatedUser.Id.ToString());

            return Ok(new
            {
                Token = token,
                RefreshToken = newRefreshToken
            });
        }
    }
}
