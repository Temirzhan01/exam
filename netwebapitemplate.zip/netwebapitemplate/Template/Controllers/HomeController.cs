﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Template.Extensions;
using Template.Models;
using Template.Services.Abstract;

namespace Template.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IService _service;
        private readonly IRedisService _redisService;
        //private readonly IKafkaProducer<string, string> _producer;

        public HomeController(ILogger<HomeController> logger, IService service, IRedisService redisService/*, IKafkaProducer<string, string> producer*/)
        {
            _logger = logger;
            _service = service;
            _redisService = redisService;
            //_producer = producer;
        }

        [HttpGet]
        [Route("GetAllFromDBOracle")]
        public async Task<IActionResult> GetAllFromDBOracle()
        {
            var result = await _service.GetAllFromDBOracleAsync();
            if (result.Count() < 1)
            {
                return NoContent();
            }

            return Ok(result);
        }

        [HttpGet]
        [Route("GetAllFromDBPostgre")]
        public async Task<IActionResult> GetAllFromDBPostgre()
        {
            var result = await _service.GetAllFromDBPostgreAsync();
            if (result.Count() < 1)
            {
                return NoContent();
            }

            return Ok(result);
        }

        [HttpGet]
        [Route("GetFromRedis/{key}")]
        public async Task<IActionResult> GetFromRedis(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return BadRequest();
            }
            var result = await _redisService.GetValueAsync(key);
            if (result == null)
            {
                return NoContent();
            }

            return Ok(result);
        }

        [HttpPost]
        [Route("SetInRedis")]
        public async Task<IActionResult> SetInRedis([FromBody] ExampleModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _redisService.SetValueAsync(model);

            return Ok();

        }

        /*[HttpPost]
        [Route("ProduceToKafka")]
        public async Task<IActionResult> ProduceToKafka([FromBody] ExampleModel body)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _producer.ProduceAsync(body.key, JsonConvert.SerializeObject(body));

            return Ok();
        }*/

        [HttpPost]
        [Route("RestExternalServiceCall")]
        public async Task<IActionResult> RestExternalServiceCall()
        {
            return Ok(await _service.RestServiceCallAsync());
        }

        [HttpPost]
        [Route("SoapExternalServiceCall")]
        public async Task<IActionResult> SoapExternalServiceCall()
        {
            return Ok(await _service.SoapServiceCallAsync());
        }

    }
}
