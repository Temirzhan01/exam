﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Template.Models;
using Template.Services.Interfaces;

namespace Template.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IService _service;
        private readonly IRedisService _redisService;
        private readonly IKafkaProducer<string, string> _producer;

        public HomeController(ILogger<HomeController> logger, IService service, IRedisService redisService, IKafkaProducer<string, string> producer)
        {
            _logger = logger;
            _service = service;
            _redisService = redisService;
            _producer = producer;
        }

        //[Authorize]
        [HttpGet]
        [Route("GetFromRedis/{key}")]
        public async Task<IActionResult> GetFromRedis(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return BadRequest();
            }
            var result = await _redisService.GetValueAsync(key);
            if (result == null)
            {
                return NoContent();
            }

            return Ok(result);
        }

        //[Authorize]
        [HttpPost]
        [Route("SetInRedis")]
        public async Task<IActionResult> SetInRedis([FromBody] ExampleModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _redisService.SetValueAsync(model);

            return Ok();

        }

        //[Authorize]
        [HttpPost]
        [Route("ProduceToKafka")]
        public async Task<IActionResult> ProduceToKafka([FromBody] ExampleModel body)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _producer.ProduceAsync(body.key, JsonConvert.SerializeObject(body));

            return Ok();
        }

        //[Authorize]
        [HttpPost]
        [Route("RestExternalServiceCall")]
        public async Task<IActionResult> RestExternalServiceCall()
        {
            return Ok(await _service.RestServiceCallAsync());
        }

        //[Authorize]
        [HttpPost]
        [Route("SoapExternalServiceCall")]
        public async Task<IActionResult> SoapExternalServiceCall()
        {
            return Ok(await _service.SoapServiceCallAsync());
        }

    }
}
