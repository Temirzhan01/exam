﻿using Microsoft.AspNetCore.Mvc;
using Template.Models.Dto;
using Template.Services.Interfaces;

namespace Template.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        //[Authorize]
        [HttpGet]
        [Route("GET")]
        public async Task<IActionResult> Get()
        {
            var result = await _userService.GetAllAsync();
            if (result.Count() < 1)
            {
                return NoContent();
            }
            return Ok();
        }

        //[Authorize]
        [HttpGet]
        [Route("GET/{id}")]
        public async Task<IActionResult> Get(int id) 
        {
            var result = await _userService.GetByIdAsync(id);
            if (result.Equals(null)) 
            {
                return NoContent();
            }
            return Ok();
        }

        //[Authorize]
        [HttpPost]
        [Route("POST")]
        public async Task<IActionResult> Post([FromBody] CreateUserDto dto)
        {
            if (!ModelState.IsValid) 
            {
                return BadRequest(ModelState);
            }
            await _userService.CreateAsync(dto);
            return Ok();
        }

        //[Authorize]
        [HttpPut]
        [Route("PUT")]
        public async Task<IActionResult> Update([FromBody] UpdateUserDto dto) 
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _userService.UpdateAsync(dto);
            return Ok();
        }

        //[Authorize]
        [HttpDelete]
        [Route("DELETE/{id}")]
        public async Task<IActionResult> Delete(int id) 
        {
            await _userService.DeleteAsync(id);
            return Ok();
        }
    }
}
