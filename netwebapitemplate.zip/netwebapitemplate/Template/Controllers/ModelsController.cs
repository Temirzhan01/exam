﻿using Microsoft.AspNetCore.Mvc;
using Template.Models.Dto;
using Template.Services.Interfaces;

namespace Template.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModelsController : ControllerBase
    {
        private readonly IModelService _modelService;
        public ModelsController(IModelService modelService)
        {
            _modelService = modelService;
        }

        [HttpGet]
        [Route("GET")]
        public async Task<IActionResult> GetModel()
        {
            var result = await _modelService.GetAll();
            if (result.Count() < 1)
            {
                return NoContent();
            }
            return Ok();
        }

        [HttpPost]
        [Route("POST")]
        public async Task<IActionResult> CreateModel([FromBody] CreateModelDto dto)
        {
            return Ok(await _modelService.CreateModel(dto));
        }
    }
}
