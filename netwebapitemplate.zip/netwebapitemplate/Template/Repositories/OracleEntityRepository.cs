﻿using Microsoft.EntityFrameworkCore;
using Template.Data;
using Template.Models;
using Template.Repositories.Abstract;

namespace Template.Repositories
{
    public class OracleEntityRepository : IRepository<Entity>
    {
        private readonly OracleDbContext _context;
        public OracleEntityRepository(OracleDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Entity>> GetAllAsync()
        {
            return await _context.Entities.ToListAsync();
        }
        public async Task<Entity> GetByIdAsync(int id)
        {
            return await _context.Entities.FindAsync(id);
        }
        public async Task AddAsync(Entity entity)
        {
            await _context.Entities.AddAsync(entity);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(Entity entity)
        {
            _context.Entities.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Entities.FindAsync(id);
            if (entity != null)
            {
                _context.Entities.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
