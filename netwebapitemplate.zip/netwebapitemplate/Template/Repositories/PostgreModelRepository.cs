﻿using Microsoft.EntityFrameworkCore;
using Template.Data;
using Template.Models;
using Template.Repositories.Abstract;

namespace Template.Repositories
{
    public class PostgreModelRepository : IRepository<Model>
    { 
        private readonly PostgreDbContext _context;
        public PostgreModelRepository(PostgreDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Model>> GetAllAsync() 
        {
            return await _context.Models.ToListAsync();
        }
        public async Task<Model> GetByIdAsync(int id) 
        {
            return await _context.Models.FindAsync(id);
        }
        public async Task AddAsync(Model entity) 
        {
            await _context.Models.AddAsync(entity);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(Model entity) 
        {
            _context.Models.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id) 
        {
            var entity = await _context.Models.FindAsync(id);
            if (entity != null)
            {
                _context.Models.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
