﻿using System.Linq.Expressions;
using Template.Repositories.Abstract;

namespace Template.Repositories.Interfaces
{
    public interface IUserRepository<T> : IRepository<T>
    {
        Task<T> GetByCriteriaAsync(Expression<Func<T, bool>> criteria);
    }
}
