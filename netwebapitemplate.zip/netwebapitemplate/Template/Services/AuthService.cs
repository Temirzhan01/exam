﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using Template.Extensions;
using Template.Models;
using Template.Repositories.Interfaces;
using Template.Services.Interfaces;

namespace Template.Services
{
    public class AuthService : IAuthService
    {
        private readonly ILogger<AuthService> _logger;
        private readonly IUserRepository<User> _userRepository;
        
        public AuthService( ILogger<AuthService> logger, IUserRepository<User> userRepository) 
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        public async Task<string> GenerateJWT(User user) 
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, user.Login),
                    new Claim(ClaimTypes.Email, user.Email),
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Role, "User"),
                }),
                Expires = DateTime.UtcNow.AddMinutes(BearerAuthExtension._lifeTime),
                SigningCredentials = new SigningCredentials(BearerAuthExtension.GetSymmetricSecutiryKey(), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        public async Task<string> GenerateRefreshTokenAsync(string userId)
        {
            var refreshToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
            await StoreRefreshTokenAsync(userId, refreshToken);
            return refreshToken;
        }

        public async Task<bool> ValidateRefreshTokenAsync(string userId, string refreshToken)
        {
            //var user = await _context.Users.Include(u => u.RefreshTokens).SingleOrDefaultAsync(u => u.Id == userId);
            //return user?.RefreshTokens.Any(rt => rt.Token == refreshToken && rt.IsActive) ?? false;
            return false;
        }

        public async Task<User> GetUserByRefreshTokenAsync(string refreshToken)
        {
            //return await _context.Users.Include(u => u.RefreshTokens).SingleOrDefaultAsync(u => u.RefreshTokens.Any(rt => rt.Token == refreshToken && rt.IsActive));
            return null;
        }

        public async Task StoreRefreshTokenAsync(string userId, string refreshToken)
        {
            //var user = await _context.Users.SingleOrDefaultAsync(u => u.Id == userId);
            //if (user != null)
            //{
            //    user.RefreshTokens.Add(new RefreshToken
            //    {
            //        Token = refreshToken,
            //        Expires = DateTime.UtcNow.AddDays(7),
            //        Created = DateTime.UtcNow
            //    });
            //    await _context.SaveChangesAsync();
            //}
        }
    }
}
