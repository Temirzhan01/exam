﻿using Template.Services.Interfaces;

namespace Template.Services
{
    public class UserService : IUserService
    {
        
    }
}
