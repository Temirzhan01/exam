﻿using AutoMapper;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using Template.Extensions;
using Template.Models;
using Template.Models.Dto;
using Template.Repositories.Interfaces;
using Template.Services.Interfaces;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Template.Services
{
    public class UserService : IUserService
    {
        private readonly ILogger<UserService> _logger;
        private readonly IUserRepository<User> _userRepository;
        private readonly IMapper _mapper;
        private readonly IMemoryCache _memoryCache;
        public UserService(ILogger<UserService> logger, IUserRepository<User> repository, IMapper mapper, IMemoryCache memoryCache)
        {
            _logger = logger;
            _userRepository = repository;
            _mapper = mapper;
            _memoryCache = memoryCache;
        }

        public async Task<IEnumerable<UserDto>> GetAllAsync()
        {
            try
            {
                var users = await _userRepository.GetAllAsync();
                return _mapper.Map<List<UserDto>>(users);
            }
            catch (Exception ex)
            {
                string Action = "GetAllAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while querying in db", null, null, null);
                throw;
            }
        }
        public async Task<UserDto> GetByIdAsync(int id)
        {
            try
            {
                var user = await _userRepository.GetByIdAsync(id);
                return _mapper.Map<UserDto>(user);
            }
            catch (Exception ex)
            {
                string Action = "GetByIdAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while querying in db", null, null, id.ToString());
                throw;
            }
        }
        public async Task CreateAsync(CreateUserDto dto)
        {
            try
            {
                var user = _mapper.Map<User>(dto);
                await _userRepository.AddAsync(user);
            }
            catch (Exception ex)
            {
                string Action = "CreateAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while add in db", null, null, JsonConvert.SerializeObject(dto));
                throw;
            }
        }
        public async Task UpdateAsync(UpdateUserDto dto)
        {
            try
            {
                var user = _mapper.Map<User>(dto);
                await _userRepository.UpdateAsync(user);
            }
            catch (Exception ex)
            {
                string Action = "UpdateAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while update in db", null, null, JsonConvert.SerializeObject(dto));
                throw;
            }
        }
        public async Task DeleteAsync(int id)
        {
            try
            {
                await _userRepository.DeleteAsync(id);
            }
            catch (Exception ex)
            {
                string Action = "DeleteAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while deleting in db", null, null, id.ToString());
                throw;
            }
        }

        public async Task<bool> CheckCredentialsAsync(User model)
        {
            try
            {
                User user = await TryGetFromCache(model.Login);

                if (user == null)
                {
                    return false;
                }

                if (model.Password != user.Password)
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                string Action = "CheckCredentialsAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error on authorization", null, null, JsonConvert.SerializeObject(model));
                throw;
            }
        }

        public async Task<User> CheckCredentialsAndGetAsync(User model)
        {
            try
            {
                User user = await TryGetFromCache(model.Login);

                if (user == null)
                {
                    return null;
                }

                if (model.Password != user.Password)
                {
                    return null;
                }
                return user;
            }
            catch (Exception ex)
            {
                string Action = "CheckCredentialsAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error on authorization", null, null, JsonConvert.SerializeObject(model));
                throw;
            }
        }
        public async Task<User> TryGetFromCache(string login) 
        {
            User user;
            if (!_memoryCache.TryGetValue(login, out string cachedDAta))
            {
                user = await _userRepository.GetByCriteriaAsync(u => u.Login.ToLower() == login.ToLower());

                cachedDAta = JsonConvert.SerializeObject(user);

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetSize(1)
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(5))
                .SetSlidingExpiration(TimeSpan.FromMinutes(3));

                _memoryCache.Set(login, cacheEntryOptions);
            }

            user = JsonConvert.DeserializeObject<User>(cachedDAta);

            return user;
        }
    }
}
