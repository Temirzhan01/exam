﻿using Newtonsoft.Json;
using Template.Services.Interfaces;
using System.Text;
using Template.Models;
using ServiceReference;
using Template.Extensions;

namespace Template.Services
{
    public class Service : IService
    {
        private readonly ILogger<Service> _logger;
        private readonly HttpClient _httpClient;
        private readonly PublisherSoapClient _publisher;

        public Service(IConfiguration configuration, ILogger<Service> logger, IHttpClientFactory factory, PublisherSoapClient publisher)
        {
            _logger = logger;
            _httpClient = factory.CreateClient("RESTClient");
            _publisher = publisher;
        }
        public async Task<ExampleModel> RestServiceCallAsync()
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(new { Example = "Example" }), Encoding.UTF8, "application/json");
                var message = new HttpRequestMessage(HttpMethod.Post, $"/somepathtoendpoint") { Content = content };
                using (HttpResponseMessage response = await _httpClient.SendAsync(message))
                {
                    response.EnsureSuccessStatusCode();
                    return JsonConvert.DeserializeObject<ExampleModel>(await response.Content.ReadAsStringAsync());
                }
            }
            catch (Exception ex)
            {
                string Action = "RestServiceCallAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while handling request to external service", null, null, ex.InnerException.Message);
                throw ex;
            }

        }
        public async Task<Carrier> SoapServiceCallAsync()
        {
            try
            {
                return await _publisher.GetModelAsync();
            }
            catch (Exception ex) 
            {
                string Action = "SoapServiceCallAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while handling request to external service", null, null, ex.InnerException.Message);
                throw ex;
            }
        }
    }
}
