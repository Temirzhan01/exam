﻿using Newtonsoft.Json;
using Template.Repositories.Abstract;
using Template.Services.Abstract;
using System.Text;
using Template.Models;
using ServiceReference;
using Template.Extensions;

namespace Template.Services
{
    public class Service : IService
    {
        private readonly ILogger<Service> _logger;
        private readonly IRepository<Entity> _oracleEntityRepo;
        private readonly IRepository<Model> _postgreEntityRepo;
        private readonly HttpClient _httpClient;
        private readonly PublisherSoapClient _publisher;

        public Service(IConfiguration configuration, ILogger<Service> logger, IHttpClientFactory factory, IRepository<Entity> oracleRepo, IRepository<Model> postgreRepo, PublisherSoapClient publisher)
        {
            _logger = logger;
            _httpClient = factory.CreateClient("RESTClient");
            _postgreEntityRepo = postgreRepo;
            _oracleEntityRepo = oracleRepo;
            _publisher = publisher;
        }

        public async Task<IEnumerable<Entity>> GetAllFromDBOracleAsync()
        {
            try
            {
                return await _oracleEntityRepo.GetAllAsync();
            }
            catch (Exception ex)
            {
                string Action = "GetAllFromDBOracleAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while handling database action", null, null, ex.InnerException.Message);
                throw ex;
            }
        }

        public async Task<IEnumerable<Model>> GetAllFromDBPostgreAsync()
        {
            try
            {
                return await _postgreEntityRepo.GetAllAsync();
            }
            catch (Exception ex)
            {
                string Action = "GetAllFromDBPostgreAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while handling database action", null, null, ex.InnerException.Message);
                throw ex;
            }
        }

        public async Task<ExampleModel> RestServiceCallAsync()
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(new { Example = "Example" }), Encoding.UTF8, "application/json");
                var message = new HttpRequestMessage(HttpMethod.Post, $"/somepathtoendpoint") { Content = content };
                using (HttpResponseMessage response = await _httpClient.SendAsync(message))
                {
                    response.EnsureSuccessStatusCode();
                    return JsonConvert.DeserializeObject<ExampleModel>(await response.Content.ReadAsStringAsync());
                }
            }
            catch (Exception ex)
            {
                string Action = "RestServiceCallAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while handling request to external service", null, null, ex.InnerException.Message);
                throw ex;
            }

        }
        public async Task<Carrier> SoapServiceCallAsync()
        {
            try
            {
                return await _publisher.GetModelAsync();
            }
            catch (Exception ex) 
            {
                string Action = "SoapServiceCallAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while handling request to external service", null, null, ex.InnerException.Message);
                throw ex;
            }
        }
    }
}
