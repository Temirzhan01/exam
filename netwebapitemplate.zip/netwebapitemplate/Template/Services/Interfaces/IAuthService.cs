﻿using Template.Models;

namespace Template.Services.Interfaces
{
    public interface IAuthService
    {
        Task<string> GenerateJWT(User user);
        Task<string> GenerateRefreshTokenAsync(string userId);
        Task<bool> ValidateRefreshTokenAsync(string userId, string refreshToken);
        Task<User> GetUserByRefreshTokenAsync(string refreshToken);
        Task StoreRefreshTokenAsync(string userId, string refreshToken);
    }
}
