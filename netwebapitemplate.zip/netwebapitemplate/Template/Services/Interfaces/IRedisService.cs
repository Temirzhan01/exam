﻿using Template.Models;

namespace Template.Services.Interfaces
{
    public interface IRedisService
    {
        Task<string> GetValueAsync(string key);
        Task SetValueAsync(ExampleModel model);
        Task<bool> DeleteKeyAsync(string key);
    }
}
