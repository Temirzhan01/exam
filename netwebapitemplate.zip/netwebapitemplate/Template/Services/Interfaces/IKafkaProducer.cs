﻿namespace Template.Services.Interfaces
{
    public interface IKafkaProducer<Tkey, TValue>
    {
        Task ProduceAsync(Tkey key, TValue value);
    }
}
