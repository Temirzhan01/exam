﻿using Template.Models;

namespace Template.Services.Interfaces
{
    public interface IUserService
    {
        public Task<bool> CheckCredentialsAsync(User user);
    }
}
