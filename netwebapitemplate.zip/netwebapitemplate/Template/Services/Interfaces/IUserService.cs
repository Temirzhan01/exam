﻿using Template.Models;
using Template.Models.Dto;

namespace Template.Services.Interfaces
{
    public interface IUserService
    {
        Task<IEnumerable<UserDto>> GetAllAsync();
        Task<UserDto> GetByIdAsync(int id);
        Task CreateAsync(CreateUserDto dto);
        Task UpdateAsync(UpdateUserDto dto);
        Task DeleteAsync(int id);
        Task<bool> CheckCredentialsAsync(User user);
        Task<User> CheckCredentialsAndGetAsync(User user);
    }
}
