﻿using Template.Models.Dto;

namespace Template.Services.Interfaces
{
    public interface IModelService
    {
        public Task<IEnumerable<ModelDto>> GetAll();
        public Task<ModelDto> CreateModel(CreateModelDto dto);
    }
}
