﻿using ServiceReference;
using Template.Models;

namespace Template.Services.Interfaces
{
    public interface IService
    {
        Task<ExampleModel> RestServiceCallAsync();
        Task<Carrier> SoapServiceCallAsync();
    }
}
