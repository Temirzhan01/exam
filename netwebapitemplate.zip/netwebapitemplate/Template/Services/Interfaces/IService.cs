﻿using ServiceReference;
using Template.Models;

namespace Template.Services.Abstract
{
    public interface IService
    {
        Task<IEnumerable<Entity>> GetAllFromDBOracleAsync();
        Task<IEnumerable<Model>> GetAllFromDBPostgreAsync();
        Task<ExampleModel> RestServiceCallAsync();
        Task<Carrier> SoapServiceCallAsync();
    }
}
