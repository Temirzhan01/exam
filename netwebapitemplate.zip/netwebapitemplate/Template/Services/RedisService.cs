﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using StackExchange.Redis;
using Template.Extensions;
using Template.Models;
using Template.Services.Interfaces;

namespace Template.Services
{
    public class RedisService : IRedisService
    {
        private readonly IConnectionMultiplexer _connectionMultiplexer;
        private readonly ILogger<RedisService> _logger;

        public RedisService(IConnectionMultiplexer connectionMultiplexer, ILogger<RedisService> logger)
        {
            _connectionMultiplexer = connectionMultiplexer;
            _logger = logger;
        }

        public async Task<string> GetValueAsync(string key)
        {
            try 
            {
                var db = _connectionMultiplexer.GetDatabase();
                return await db.StringGetAsync(key);
            }
            catch (Exception ex) 
            {
                string Action = "GetValueAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while querying in Redis attempt", null, null, key);
                throw;
            }
        }

        public async Task SetValueAsync(ExampleModel model)
        {
            try 
            {
                var db = _connectionMultiplexer.GetDatabase();
                await db.StringSetAsync(model.key, model.value);
            }
            catch (Exception ex)
            {
                string Action = "SetValueAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while setting in Redis attempt", null, null, JsonConvert.SerializeObject(model));
                throw;
            }
        }

        public async Task<bool> DeleteKeyAsync(string key)
        {
            try 
            {
                var db = _connectionMultiplexer.GetDatabase();
                return await db.KeyDeleteAsync(key);
            }
            catch (Exception ex)
            {
                string Action = "DeleteKeyAsync";
                _logger.LogErrorCustom(Action, ex.Message, "Error while deleting in Redis attempt", null, null, key);
                throw;
            }
        }
    }
}
