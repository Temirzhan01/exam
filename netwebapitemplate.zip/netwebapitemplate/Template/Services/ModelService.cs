﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Template.Data;
using Template.Models;
using Template.Models.Dto;
using Template.Services.Interfaces;

namespace Template.Services
{
    public class ModelService : IModelService
    {
        private readonly IMapper _mapper;
        private readonly PostgreDbContext _dbContext;

        public ModelService(IMapper mapper, PostgreDbContext dbContext)
        {
            _mapper = mapper;
            _dbContext = dbContext;
        }

        public async Task<ModelDto> CreateModel(CreateModelDto dto)
        {
            var model = _mapper.Map<CreateModelDto, Model>(dto);
            var newModel = await _dbContext.AddAsync(model);
            await _dbContext.SaveChangesAsync();
            return _mapper.Map<Model, ModelDto>(newModel.Entity);
        }

        public async Task<IEnumerable<ModelDto>> GetAll()
        {
            var models = await _dbContext.Models.ToListAsync();
            return _mapper.Map<List<Model>, List<ModelDto>>(models);
        }
    }
}
