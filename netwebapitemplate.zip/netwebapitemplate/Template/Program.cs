using Serilog.Formatting.Elasticsearch;
using Serilog;
using Template.Extensions;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Newtonsoft.Json;
using Template.Extensions.Configuration;
using Template.Extensions.MiddleWares;

var builder = WebApplication.CreateBuilder(args);

Serilog.Debugging.SelfLog.Enable(Console.Error);

Log.Logger = new LoggerConfiguration() // Настраиваем глобальный логгер проекта Serilog, с выводом в консоль логов, читаем для Еластика формате
    .Enrich.FromLogContext()
    .WriteTo.Console(new ElasticsearchJsonFormatter())
    .CreateLogger();

builder.Host.UseSerilog();

builder.AddConsulConfiguration(); // Получаем конфигурации проекта из консула, при первичном запуске проекта

builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
builder.Services.AddAutoMapper(typeof(Program)); //Добавляем наши конфигураций, также можно писать через запятую несколько профилей
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder => builder.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(_ => true));
});
builder.AddServices(); // Внедряем все зависимости проекта
builder.AddDbContexts(); // Внедряем контексты бд
//builder.AddKafka(); // Внедряем кафку
builder.AddRedis(); // Внедряем редис
builder.AddModelService();

var app = builder.Build();

app.MapHealthChecks("/healthz", new HealthCheckOptions // Добавляем endpoint для получения хелзчека работы приложения, и настраиваем для вывода в едином формате 
{
    ResponseWriter = async (context, report) => {
        context.Response.ContentType = "application/json";
        var result = new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(x => new { name = x.Key, response = x.Value.Status.ToString(), description = x.Value.Description })
        };
        await context.Response.WriteAsync(JsonConvert.SerializeObject(result));
    }
});

if (builder.Configuration["SwaggerEnvironment"] == "Development")
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ApiKeyMiddleware>(); // Используем кастомный компонент middleware для аутентификации на основе апи ключа

app.UseAuthentication();
app.UseAuthorization();

app.UseHttpsRedirection();

app.UseStaticFiles();

app.MapControllers();

app.Run();
