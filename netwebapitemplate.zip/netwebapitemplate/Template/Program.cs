using Serilog.Formatting.Elasticsearch;
using Serilog;
using Template.Extensions;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Newtonsoft.Json;
using Template.Extensions.Configuration;
using Template.Extensions.MiddleWares;
using Template.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

Serilog.Debugging.SelfLog.Enable(Console.Error);

Log.Logger = new LoggerConfiguration() // Настраиваем глобальный логгер проекта Serilog, с выводом в консоль логов, читаем для Еластика формате
    .Enrich.FromLogContext()
    .WriteTo.Console(new ElasticsearchJsonFormatter())
    .CreateLogger();

builder.Host.UseSerilog();

builder.AddConsulConfiguration(); // Получаем конфигурации проекта из консула, при первичном запуске проекта

builder.ConfigureDependicies();

var app = builder.Build();

app.MapHealthChecks("/healthz", new HealthCheckOptions // Добавляем endpoint для получения хелзчека работы приложения, и настраиваем для вывода в едином формате 
{
    ResponseWriter = async (context, report) =>
    {
        context.Response.ContentType = "application/json";
        var result = new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(x => new { name = x.Key, response = x.Value.Status.ToString(), description = x.Value.Description })
        };
        await context.Response.WriteAsync(JsonConvert.SerializeObject(result));
    }
});

using (var scope = app.Services.CreateScope())
{
    if (builder.Configuration["Environment"] == "Development") // Включаем автомиграцию при билде проекта, но тут опасно, для существующих объектов в бд только в дев среде. В проде миграции руками. 
    {
        try 
        {
            var dbcontext = scope.ServiceProvider.GetRequiredService<OracleDbContext>();
            dbcontext.Database.Migrate();
        }
        catch (Exception ex) 
        {
            var _logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
            _logger.LogErrorCustom("Migrate", ex.Message, "Error while DB migrate attempt", null, null, null);
        }

        app.UseSwagger();
        app.UseSwaggerUI();
    }
}

app.UseMiddleware<ApiKeyMiddleware>(); // Используем кастомный компонент middleware для аутентификации на основе апи ключа

app.UseHttpsRedirection();

app.UseStaticFiles();

app.MapControllers();

app.Run();
