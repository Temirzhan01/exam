﻿using Microsoft.AspNetCore.Authentication;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using Template.Models;
using Template.Services.Interfaces;

namespace Template.Extensions.MiddleWares
{
    public class BasicAuthMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<BasicAuthMiddleware> _logger;

        public BasicAuthMiddleware(RequestDelegate next, ILogger<BasicAuthMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Path.Value.ToString() != "/healthz")
            {
                if (!context.Request.Headers.ContainsKey("Authorization"))
                {
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    await context.Response.WriteAsync("Missing authorization header");
                    return;
                }

                try
                {
                    var authHeader = AuthenticationHeaderValue.Parse(context.Request.Headers["Authorization"]);
                    var credentials = Encoding.UTF8.GetString(Convert.FromBase64String(authHeader.Parameter)).Split(':');
                    var username = credentials[0];
                    var password = credentials[1];

                    var _userService = context.RequestServices.GetRequiredService<IUserService>();
                    if (!await _userService.CheckCredentialsAsync(new User() { Login = username, Password = password }))
                    {
                        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                        await context.Response.WriteAsync("Invalid username or password");
                        return;
                    }

                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, username)
                    };
                    var identity = new ClaimsIdentity(claims, "Basic");
                    var principal = new ClaimsPrincipal(identity);
                    context.User = principal;
                }
                catch (Exception ex)
                {
                    _logger.LogErrorCustom("InvokeAsync", ex.Message, "Error on custom authentification middleware", null, null, JsonConvert.SerializeObject(context.Request.Headers["Authorization"]));
                    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                    return;
                }
            }

            await _next(context);
        }
    }
}
