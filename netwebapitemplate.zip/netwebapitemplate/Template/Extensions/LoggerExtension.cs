﻿namespace Template.Extensions
{
    public static class LoggerExtension
    {
        private static string _componentName { get; set; }
        public static void Initialize(string componentNameName)
        {
            _componentName = componentNameName;
        }
        public static void LogErrorCustom(this ILogger logger, string action, string message, string customMessage, string userID, string clientID, string additionalData) 
        {
            logger.LogError($"Component: {_componentName}, Action: {action}, Error message: {message}, Custom message: {customMessage}, User ID: {userID}, Client ID: {clientID}, Additional data: {additionalData}");
        }

        public static void LogInfoCustom(this ILogger logger, string action, string message, string customMessage, string userID, string clientID, string additionalData)
        {
            logger.LogInformation($"Component: {_componentName}, Action: {action}, Info message: {message}, Custom message: {customMessage}, User ID: {userID}, Client ID: {clientID}, Additional data: {additionalData}");

        }

        public static void LogDebugCustom(this ILogger logger, string action, string message, string customMessage, string userID, string clientID, string additionalData)
        {
            logger.LogDebug($"Component: {_componentName}, Action: {action}, Debug message: {message}, Custom message: {customMessage}, User ID: {userID}, Client ID: {clientID}, Additional data: {additionalData}");
        }

        public static void LogTraceCustom(this ILogger logger, string action, string message, string customMessage, string userID, string clientID, string additionalData)
        {
            logger.LogTrace($"Component: {_componentName}, Action: {action}, Trace message: {message}, Custom message: {customMessage}, User ID: {userID}, Client ID: {clientID}, Additional data: {additionalData}");

        }

        public static void LogCriticalCustom(this ILogger logger, string action, string message, string customMessage, string userID, string clientID, string additionalData)
        {
            logger.LogCritical($"Component: {_componentName}, Action: {action}, Critical message: {message}, Custom message: {customMessage}, User ID: {userID}, Client ID: {clientID}, Additional data: {additionalData}");
        }

        public static void LogWarningCustom(this ILogger logger, string action, string message, string customMessage, string userID, string clientID, string additionalData)
        {
            logger.LogWarning($"Component: {_componentName}, Action: {action}, Warning message: {message}, Custom message: {customMessage}, User ID: {userID}, Client ID: {clientID}, Additional data: {additionalData}");

        }
    }
}