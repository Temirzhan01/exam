﻿using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.IdentityModel.Tokens;

namespace Template.Extensions
{
    public static class ConfigureDependeciesExtension
    {
        public static WebApplicationBuilder ConfigureDependicies(this WebApplicationBuilder builder)
        {
            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", builder => builder.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(_ => true));
            });

            //builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
            builder.Services.AddAutoMapper(typeof(Program)); //Добавляем наши конфигураций, также можно писать через запятую несколько профилей
            builder.Services.AddHealthChecks(builder.Configuration); // добавляем кастомные хелзчеки
            builder.Services.AddMemoryCache(options =>
            {
                options.SizeLimit = 1024;
            });
            builder.Services.AddFluentValidationAutoValidation().AddValidatorsFromAssemblyContaining<Program>();
            /*builder.Services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(jwt => 
            {
                jwt.RequireHttpsMetadata = true;
                jwt.SaveToken = true;
                jwt.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey =  BearerAuthExtension.GetSymmetricSecutiryKey(),
                    ValidateIssuer = false,
                    ValidIssuer = BearerAuthExtension._issuer,
                    ValidateAudience = true,
                    ValidAudience = BearerAuthExtension._audience,
                    ValidateLifetime = true,
                };
            });
            builder.Services.AddAuthorization();*/

            LoggerExtension.Initialize(builder.Configuration["ComponentName"]); // Инициализируем расширение логера
            //BearerAuthExtension.Initialize(builder.Configuration["BearerAuthConfigurations:Key"], builder.Configuration["BearerAuthConfigurations:Audience"], builder.Configuration["BearerAuthConfigurations:Issuer"], int.Parse(builder.Configuration["BearerAuthConfigurations:LifeTime"])); // Инициализируем расширение логера

            builder.AddServices(); // Внедряем все зависимости проекта
            builder.AddDbContexts(); // Внедряем контексты бд
            builder.AddKafka(); // Внедряем кафку
            builder.AddRedis(); // Внедряем редис 

            return builder;
        }
    }
}
