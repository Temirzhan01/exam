﻿using StackExchange.Redis;
using Template.Services.Abstract;
using Template.Services;
using Template.Services.Interfaces;

namespace Template.Extensions
{
    public static class ModelExtensions
    {
        public static WebApplicationBuilder AddModelService(this WebApplicationBuilder builder)
        {
            builder.Services.AddTransient<IModelService, ModelService>();
            return builder;
        }
    }
}
