﻿using Template.Services.Interfaces;
using Template.Services;

namespace Template.Extensions
{
    public static class KafkaExtensions
    {
        public static WebApplicationBuilder AddKafka(this WebApplicationBuilder builder)
        {
            builder.Services.AddSingleton<IKafkaProducer<string, string>, KafkaProducer<string, string>>(); // внедряем продюсера кафки

            return builder;
        }
    }
}
