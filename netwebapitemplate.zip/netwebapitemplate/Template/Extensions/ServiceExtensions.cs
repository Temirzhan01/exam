﻿using Polly;
using Template.Services.Abstract;
using Template.Services;
using Template.Repositories.Abstract;
using Template.Repositories;
using ServiceReference;
using System.ServiceModel;
using Template.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

namespace Template.Extensions
{
    public static class ServiceExtensions
    {
        public static WebApplicationBuilder AddServices(this WebApplicationBuilder builder)
        {
            LoggerExtension.Initialize(builder.Configuration["ComponentName"]);

            builder.Services.AddHealthChecks(builder.Configuration); // добавляем кастомные хелзчеки

            builder.Services.AddScoped<IRepository<Entity>, OracleEntityRepository>();
            builder.Services.AddScoped<IRepository<Model>, PostgreModelRepository>();

            builder.Services.AddScoped<IService, Service>();

            builder.Services.AddHttpClient("ExampleREST", (serviceProvider, client) => // внедряем именнового клиента, с дефолтным url и настройками политик обработок запросов
            {
                client.BaseAddress = new Uri(builder.Configuration["ExternalServices:REST:ExampleRESTURL"]);
            }).AddTransientHttpErrorPolicy(p => p.CircuitBreakerAsync(5, TimeSpan.FromSeconds(30))); // добавляем политику, вкл паттерна CircuitBreaker который посел 5 неудачных попыток, будет автоматом выдавать Exception, и попытается достуаться еще раз после 30 сек

            builder.Services.AddTransient<PublisherSoapClient>(provider => // внедряем клиента soap сервиса, с явным указанием url
            {
                var serviceURL = new Uri(builder.Configuration["ExternalServices:SOAP:ExampleSOAPURL"]);
                return new PublisherSoapClient(new BasicHttpBinding(), new EndpointAddress(serviceURL));
            });

            return builder;
        }
    }
}
