﻿using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace Template.Extensions
{
    public static class BearerAuthExtension
    {
        public static string _key;
        public static string _audience;
        public static string _issuer;
        public static int _lifeTime;
        public static void Initialize(string key, string audience, string issuer, int lifeTime) 
        {
            _key = key;
            _audience = audience;
            _issuer = issuer;
            _lifeTime = lifeTime;
        }

        public static SymmetricSecurityKey GetSymmetricSecutiryKey() 
        {
            return new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_key));
        }
    }
}
