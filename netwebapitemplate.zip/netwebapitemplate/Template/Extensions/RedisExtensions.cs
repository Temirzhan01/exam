﻿using Template.Services.Interfaces;
using Template.Services;
using StackExchange.Redis;

namespace Template.Extensions
{
    public static class RedisExtensions
    {
        public static WebApplicationBuilder AddRedis(this WebApplicationBuilder builder)
        {
            builder.Services.AddSingleton<IConnectionMultiplexer>(sp =>  // внедряем настройки подключения к редису
            {
                return ConnectionMultiplexer.Connect(ConfigurationOptions.Parse(builder.Configuration["Redis:ConnectionString"]));
            });
            builder.Services.AddTransient<IRedisService, RedisService>();

            return builder;
        }
    }
}
