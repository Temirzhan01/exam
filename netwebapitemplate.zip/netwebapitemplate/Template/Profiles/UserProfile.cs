﻿using AutoMapper;
using Template.Models;
using Template.Models.Dto;

namespace Template.Profiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<CreateUserDto, User>()
                .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName} {src.MiddleName}")) //Явно указываем правила для полей у которых название отличаются
                .ReverseMap(); // Тут невяный маппинг по одинаковым названиям полей

            CreateMap<UpdateUserDto, User>()
                .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName} {src.MiddleName}"))
                .ReverseMap();

            CreateMap<User, UserDto>()
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => GetFirstName(src.FullName)))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => GetLastName(src.FullName)))
                .ForMember(dest => dest.MiddleName, opt => opt.MapFrom(src => GetMiddleName(src.FullName)))
                .ReverseMap();

        }

        private string GetFirstName(string fullName)
        {
            var parts = fullName.Split(' ');
            return parts.Length > 0 ? parts[0] : string.Empty;
        }

        private string GetLastName(string fullName)
        {
            var parts = fullName.Split(' ');
            return parts.Length > 1 ? parts[1] : string.Empty;
        }

        private string GetMiddleName(string fullName)
        {
            var parts = fullName.Split(' ');
            return parts.Length > 2 ? parts[2] : string.Empty;
        }
    }
}
