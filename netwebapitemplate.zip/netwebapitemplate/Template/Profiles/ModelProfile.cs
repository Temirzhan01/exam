﻿using AutoMapper;
using Template.Models;
using Template.Models.Dto;

namespace Template.Profiles
{
    public class ModelProfile : Profile
    {
        public ModelProfile() {
            CreateMap<Model, ModelDto>()
                .ForMember(dest => dest.FIO, opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName}"))
                .ReverseMap();
            //Явно указываем правила для полей у которых название отличаются
            CreateMap<Model, CreateModelDto>().ReverseMap();
            //Если навзани полей совпадают то указываем не явно маппер - все сделает сам
            
        }
    }
}
