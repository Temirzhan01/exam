Net 8.0 Web Api Template - Шаблон проекта

Чтобы добавить SOAP зависимость, нужно установить командой инструмент dotnet-svcutil 

dotnet tool install --global dotnet-svcutil 

И добавить командой 

dotnet-svcutil UrlOfYourSOAPService?wsdl

Если при попытке взаимодействия в гитлабе выходит ошибка: 
ssl certificate problem: self-signed certificate in certificate chain 

То нужно вбить команду git config --global http.sslBackend schannel где руками вбивается логин и пароль от гитлаба. 